# Plugin runtime

Node-side helper package for G-SAP plugins.

This package provides stable helper shapes for:

- tool definitions
- plugin lifecycle classes
- EventBus handler definitions
- provider declarations
- task and schedule helpers
- usage ledger helpers
- SessionFile media details

The runtime keeps source compatibility while G-SAP finishes its TypeScript conversion. See the root [PLUGIN_SDK.md](../../PLUGIN_SDK.md) for current authoring rules.

