# Plugin iframe SDK

Browser-side SDK helpers for G-SAP iframe plugins.

This package provides:

- iframe ready handshake
- host request helpers
- resize notifications
- theme snapshots and theme subscriptions
- toast, external-open, and clipboard capability wrappers

The public package scope is being normalized during the TypeScript conversion. Use the workspace package from this repository when developing bundled examples, and see the root [PLUGIN_SDK.md](../../PLUGIN_SDK.md) for current guidance.

